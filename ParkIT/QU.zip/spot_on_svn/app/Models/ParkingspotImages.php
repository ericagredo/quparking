<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ParkingspotImages extends Model
{
    protected $table = 'parking_spot_images';
}
