<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReviewQuestionnaires extends Model
{
    protected $table = 'review_questionnaires';
}
