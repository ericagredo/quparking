<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SurchargeAmount extends Model
{
    protected $table = 'surcharge_amount';
}
