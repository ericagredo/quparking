<?php  

//1 user rights array
if (!function_exists('admin_admin_array')) {
    function admin_admin_array() {
 $arr = array (
  0 => '1',
  1 => '2',
  2 => '3',
  3 => '4',
  4 => '10',
  5 => '11',
  6 => '12',
  7 => '14',
  8 => '15',
  9 => '5',
  10 => '6',
  11 => '7',
  12 => '8',
  13 => '9',
  14 => '13',
  15 => '17',
);


 return $arr;


    }
}


//2 user rights array
if (!function_exists('admin_test_array')) {
    function admin_test_array() {
 $arr = array (
  0 => '1',
  1 => '2',
  2 => '16',
  3 => '3',
  4 => '4',
  5 => '10',
  6 => '11',
  7 => '12',
  8 => '14',
  9 => '15',
  10 => '5',
  11 => '6',
  12 => '7',
  13 => '8',
  14 => '9',
  15 => '13',
  16 => '17',
);


 return $arr;


    }
}


//3 user rights array
if (!function_exists('admin_mayuri_array')) {
    function admin_mayuri_array() {
 $arr = array (
  0 => '1',
  1 => '2',
  2 => '16',
  3 => '3',
  4 => '4',
  5 => '10',
  6 => '11',
  7 => '12',
  8 => '14',
  9 => '15',
  10 => '9',
);


 return $arr;


    }
}


//4 user rights array
if (!function_exists('admin_test_mayuri_array')) {
    function admin_test_mayuri_array() {
 $arr = array (
  0 => '3',
  1 => '4',
  2 => '10',
  3 => '11',
  4 => '12',
  5 => '14',
  6 => '15',
  7 => '5',
  8 => '6',
  9 => '7',
  10 => '8',
);


 return $arr;


    }
}
